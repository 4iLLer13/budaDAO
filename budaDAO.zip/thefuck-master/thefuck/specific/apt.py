from thefuck.utils import which

apt_available = bool(which('apt-get'))
